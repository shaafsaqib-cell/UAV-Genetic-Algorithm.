# UAV Disaster-Zone Strategy Engine (Genetic Algorithm)

A Python simulation that evolves routes for a fleet of three UAVs over a synthetic disaster grid. The Genetic Algorithm rewards coverage and priority detection while penalizing energy use, travel time, risk, and constraint violations.

## Project contents
- `main.py`: runs the simulation and writes JSON metrics.
- `src/ga.py`: grid, chromosome, fitness function, genetic operators, and random-search baseline.
- `src/config.py`: simulation parameters.
- `src/visualize.py`: creates four plots.
- `outputs/`: generated figures, metrics, and experiment CSV files (created after running the scripts).
- `TECHNICAL_REPORT.md`: technical report draft; fill in measured sensitivity results before submission.
- `run_sensitivity.py`: controlled parameter-sensitivity experiments.

## Run locally or in Google Colab
1. Install requirements: `pip install -r requirements.txt`
2. Run the baseline simulation: `python main.py`
3. Run sensitivity tests: `python run_sensitivity.py`

Outputs are saved in `outputs/`. Sensitivity tests use the same random seed and vary one parameter at a time. For stronger evidence, increase `REPEATS` in `run_sensitivity.py` and report the actual recorded values.

## Upload to GitHub
Create a new repository on GitHub, then upload the contents of this folder. Do not upload passwords, API keys, or private data.

## Important limitation
This is an educational simulation, not flight-control software. Its distance, time, energy, and obstacle models are simplified and must not be used to operate real UAVs.
