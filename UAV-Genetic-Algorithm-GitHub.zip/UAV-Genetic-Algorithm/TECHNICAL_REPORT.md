# UAV Disaster-Zone Strategy Engine Using a Genetic Algorithm
*Technical report draft. The included sensitivity sweep uses one seed and five generations per configuration, so treat its findings as preliminary; increase repeats and generations for stronger conclusions.*

## 1. Introduction
Disaster response and autonomous surveillance require UAV fleets to inspect high-priority regions while respecting limited battery capacity, flight-time budgets, and hazardous or restricted airspace. These objectives conflict: a route that visits more cells may require additional distance and energy, while avoiding every risk pocket may reduce access to important targets. A Genetic Algorithm (GA) is appropriate because it searches a large, non-convex space of possible fleet missions and can optimize a weighted objective without requiring gradient information.

This project models a disaster area as a 50 × 50 grid. Each cell is either traversable or blocked and also has a risk value and a priority value. The simulator evolves a fleet of three UAV plans and compares the best evolved mission against a random-search baseline.

## 2. Chromosome Representation
A chromosome encodes the complete fleet mission. Each drone plan contains a fixed launch point and eight waypoints. Every waypoint has an integer x-coordinate, integer y-coordinate, a speed level from 1 to 3, and a sensor power level from 0 to 2. This hybrid representation is compact, readable, and directly maps genes to decisions:
- Coordinates determine where the UAV surveys.
- Speed affects estimated travel time and energy.
- Sensor power changes the modeled sensing radius and energy expenditure.

The fixed-length representation makes crossover predictable. The start locations are fixed in the current implementation to reduce search complexity; they could be added as genes in a future version. Waypoint genes are repaired after initialization and mutation if they land outside the grid or inside a no-fly cell.

## 3. Fitness Function and Constraints
The fitness function is:

**F = 8C + 4D − 0.035E − 0.025T − 0.12R − 2V**

Here, C is the fraction of traversable cells covered by at least one sensor footprint; D is normalized priority-weighted detection; E is an energy proxy; T is estimated travel time; R is average risk at sampled waypoints; and V counts detected constraint violations. Larger values indicate better candidate missions.

Coverage and detection have positive coefficients because the mission should survey a large portion of the area and prioritize disaster hotspots. Energy and time have negative coefficients to favor longer-lasting, faster missions. Risk is penalized to discourage prolonged exposure to hazardous cells. Constraint violations receive an additional penalty. The weights are initial engineering choices rather than universal constants; their sensitivity should be assessed against mission priorities.

The repair operator clamps coordinates to the grid and moves blocked waypoints to the nearest safe cell. Straight-line segments that sample through blocked cells incur penalties. This is a simplified educational constraint model: a real deployment should use grid-based pathfinding between waypoints, enforce battery and time budgets explicitly, and validate every segment against map and aircraft constraints.

## 4. Genetic Operators and Termination
The initial population is generated randomly from valid cells. Tournament selection chooses parents by sampling a small group and selecting the highest-fitness member. Segment crossover takes a prefix of a route from one parent and the remaining waypoint, speed, and sensor genes from the other. Occasionally, a whole route segment is swapped to preserve useful route patterns.

Mutation changes waypoint coordinates with a local spatial move most of the time and a global random relocation occasionally. Speed and sensor levels can also mutate. Local mutation refines existing paths; global mutation helps retain diversity and escape local optima. Elitism copies the best few chromosomes into the next generation so that strong solutions are not lost. The algorithm terminates after a fixed number of generations; a practical extension would also stop after a chosen number of generations without improvement.

## 5. Experimental Evaluation
The implementation saves best and average fitness by generation, the final flight paths over the risk map, a coverage heatmap, and a histogram comparing the GA's best fitness with 1,000 random candidate missions. The results are stored in `outputs/results.json`.

### 5.1 Hyperparameter sensitivity
Run controlled experiments, changing one parameter at a time while keeping the grid seed and other parameters fixed. Repeat each configuration using at least five random seeds where feasible.

| Parameter | Suggested values | Expected trade-off to test |
|---|---|---|
| Population size | 30, 70, 120 | Larger populations explore more candidates per generation but take longer |
| Mutation rate | 0.03, 0.12, 0.25 | Low rates may stagnate; high rates can disrupt useful route segments |
| Tournament size | 2, 4, 7 | Larger tournaments increase selection pressure, potentially improving speed but reducing diversity |

Record best fitness, coverage, detection, energy, time, risk, and runtime. The included exploratory sweep was run with random seed 42 and five generations per configuration to keep execution time manageable. In this run, the highest fitness within the population-size group was obtained at population size 120 (−7.747); within the mutation-rate group, 0.03 gave the highest fitness (−10.418); and within the tournament-size group, 7 gave the highest fitness (−9.071). These values are in `outputs/sensitivity_results.csv`, with corresponding charts in `outputs/`. Because each setting was tested only once and for five generations, these are preliminary observations, not reliable universal optima. Run more generations and at least five seeds before drawing firm conclusions.

### 5.2 Comparison with random search
Random search evaluates independent random chromosomes without using parent selection, crossover, or evolutionary improvement. The same fitness function is used for a fair objective comparison. The histogram in `outputs/random_search_comparison.png` displays the random-candidate distribution and marks the GA best score. The actual scores from `outputs/results.json` should be quoted in the final report.

The GA's potential advantage is reuse of good partial routes through selection and crossover, followed by mutation-based exploration. However, a GA is not guaranteed to beat random search in every run. Fair comparisons should use similar evaluation budgets and multiple seeds. Report the measured fitness difference and compare mission metrics, not fitness alone.

## 6. Discussion and Limitations
This prototype demonstrates a complete optimization workflow and creates reproducible artifacts. The objective weights are transparent, and the hybrid chromosome can represent spatial and operational decisions. Nevertheless, the environment and vehicle models are simplified. Coverage uses circular sensor footprints; energy and time are proxies; and obstacle crossing is approximated by sampled straight-line segments. The model does not simulate wind dynamics, communication loss, battery discharge curves, collision avoidance, or multi-agent deconfliction.

A stronger version would use A* or another grid path planner between genes, explicit maximum battery and mission-time constraints, dynamic hazard updates, and a Pareto-based algorithm such as NSGA-II when decision-makers need several non-dominated trade-off solutions rather than one weighted score.

## 7. Conclusion
The project provides a modular GA strategy engine for educational UAV deployment optimization. It includes a hybrid chromosome, weighted multi-objective fitness, spatially aware crossover and mutation, constraint repair, convergence plots, evolved path visualization, coverage heatmaps, and a random-search baseline. The final submission should include the actual generated plots and measured hyperparameter results, clearly distinguishing observed outcomes from expected behavior.
