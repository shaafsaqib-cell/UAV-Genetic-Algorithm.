Generated artifacts from the baseline run and the exploratory sensitivity sweep.

- `results.json`: baseline GA and random-search metrics.
- `sensitivity_results.csv`: one-factor-at-a-time sweep, one seed and five generations per configuration.
- `fitness_convergence.png`, `evolved_paths.png`, `coverage_heatmap.png`, `random_search_comparison.png`: baseline simulation plots.
- `sensitivity_*.png`: fitness against each tested parameter.

For a stronger analysis, increase the sensitivity generation count and run multiple seeds in `run_sensitivity.py`.
