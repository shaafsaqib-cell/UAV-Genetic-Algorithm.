"""Run the UAV Genetic Algorithm project from repository root."""
import json
from pathlib import Path
from src.config import *
from src.ga import DisasterGrid, GeneticPlanner, random_search
from src.visualize import save_plots, save_random_comparison

def main():
    grid = DisasterGrid(GRID_SIZE, RANDOM_SEED)
    planner = GeneticPlanner(
        grid, NUM_DRONES, WAYPOINTS_PER_DRONE, POPULATION_SIZE,
        GENERATIONS, MUTATION_RATE, TOURNAMENT_SIZE, ELITISM, RANDOM_SEED
    )
    best = planner.run()
    random_best, random_scores = random_search(grid, planner, samples=1000)
    save_plots(grid, planner, "outputs")
    save_random_comparison(planner, best, random_scores, "outputs")
    report = {
        "ga_best_fitness": best.fitness,
        "random_search_best_fitness": random_best.fitness,
        "ga_metrics": best.metrics,
        "random_search_metrics": random_best.metrics,
        "configuration": {
            "grid_size": GRID_SIZE, "drones": NUM_DRONES,
            "waypoints_per_drone": WAYPOINTS_PER_DRONE,
            "population_size": POPULATION_SIZE, "generations": GENERATIONS,
            "mutation_rate": MUTATION_RATE, "tournament_size": TOURNAMENT_SIZE
        }
    }
    Path("outputs/results.json").write_text(json.dumps(report, indent=2))
    print("Simulation complete. Results saved in outputs/")
    print(json.dumps(report, indent=2))

if __name__ == "__main__":
    main()
