"""One-factor-at-a-time sensitivity tests for GA parameters."""
import csv
from pathlib import Path
from src.config import GRID_SIZE, NUM_DRONES, WAYPOINTS_PER_DRONE, GENERATIONS, ELITISM, RANDOM_SEED
from src.ga import DisasterGrid, GeneticPlanner

POPULATIONS = [30, 70, 120]
MUTATION_RATES = [0.03, 0.12, 0.25]
TOURNAMENT_SIZES = [2, 4, 7]
SENSITIVITY_GENERATIONS = 5  # Lightweight sweep; increase for deeper experiments.
REPEATS = 1  # Set to 5 or more for more robust results.


def run_case(parameter, value, seed):
    pop = value if parameter == "population_size" else 70
    mut = value if parameter == "mutation_rate" else 0.12
    tour = value if parameter == "tournament_size" else 4
    grid = DisasterGrid(GRID_SIZE, seed)
    planner = GeneticPlanner(grid, NUM_DRONES, WAYPOINTS_PER_DRONE, pop,
                             SENSITIVITY_GENERATIONS, mut, tour, ELITISM, seed)
    best = planner.run()
    return {
        "parameter": parameter,
        "value": value,
        "seed": seed,
        "best_fitness": best.fitness,
        "coverage": best.metrics["coverage"],
        "detection": best.metrics["detection"],
        "energy": best.metrics["energy"],
        "time": best.metrics["time"],
        "risk": best.metrics["risk"],
        "violations": best.metrics["violations"],
    }


def main():
    rows = []
    cases = [("population_size", v) for v in POPULATIONS]
    cases += [("mutation_rate", v) for v in MUTATION_RATES]
    cases += [("tournament_size", v) for v in TOURNAMENT_SIZES]
    for parameter, value in cases:
        for repeat in range(REPEATS):
            seed = RANDOM_SEED + repeat
            row = run_case(parameter, value, seed)
            rows.append(row)
            print(row)
    out = Path("outputs")
    out.mkdir(exist_ok=True)
    target = out / "sensitivity_results.csv"
    with target.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=rows[0].keys())
        writer.writeheader()
        writer.writerows(rows)
    print(f"Saved sensitivity results to {target}")


if __name__ == "__main__":
    main()
