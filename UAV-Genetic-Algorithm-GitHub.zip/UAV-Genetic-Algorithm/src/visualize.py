"""Create plots for the UAV Genetic Algorithm project."""
from pathlib import Path
import matplotlib.pyplot as plt
import numpy as np


def save_plots(grid, planner, output_dir="outputs"):
    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)

    fig, ax = plt.subplots(figsize=(8, 5))
    ax.plot(range(1, len(planner.history_best) + 1), planner.history_best, label="Best fitness")
    ax.plot(range(1, len(planner.history_avg) + 1), planner.history_avg, label="Average fitness")
    ax.set(title="GA Fitness Convergence", xlabel="Generation", ylabel="Fitness")
    ax.legend(); ax.grid(alpha=0.25); fig.tight_layout()
    fig.savefig(out / "fitness_convergence.png", dpi=160); plt.close(fig)

    fig, ax = plt.subplots(figsize=(8, 7))
    ax.imshow(grid.risk, origin="lower", cmap="YlOrRd", vmin=0, vmax=1)
    ax.contour(grid.blocked, levels=[0.5], colors="black", linewidths=0.8)
    for i, plan in enumerate(planner.best.plans):
        pts = [plan.start] + plan.waypoints
        xs, ys = zip(*pts)
        ax.plot(xs, ys, marker="o", linewidth=1.8, markersize=3, label=f"UAV {i+1}")
        ax.scatter(xs[0], ys[0], marker="s", s=45)
    ax.set(title="Best Evolved UAV Paths over Risk Map", xlabel="X coordinate", ylabel="Y coordinate")
    ax.legend(); fig.tight_layout(); fig.savefig(out / "evolved_paths.png", dpi=160); plt.close(fig)

    covered = np.zeros((grid.size, grid.size), dtype=bool)
    for plan in planner.best.plans:
        for idx, (x, y) in enumerate([plan.start] + plan.waypoints):
            sensor = plan.sensors[min(idx, len(plan.sensors)-1)] if plan.sensors else 0
            radius = 1.0 + sensor * 1.5
            x0, x1 = max(0, int(x-radius)), min(grid.size, int(x+radius+1))
            y0, y1 = max(0, int(y-radius)), min(grid.size, int(y+radius+1))
            yy, xx = np.mgrid[y0:y1, x0:x1]
            mask = (xx-x)**2 + (yy-y)**2 <= radius**2
            covered[y0:y1, x0:x1] |= mask & (~grid.blocked[y0:y1, x0:x1])
    coverage_map = covered.astype(float)
    coverage_map[grid.blocked] = np.nan
    fig, ax = plt.subplots(figsize=(7, 6))
    ax.imshow(coverage_map, origin="lower", cmap="Blues", vmin=0, vmax=1)
    ax.contour(grid.blocked, levels=[0.5], colors="black", linewidths=0.8)
    ax.set(title="UAV Sensor Coverage Heatmap", xlabel="X coordinate", ylabel="Y coordinate")
    fig.tight_layout(); fig.savefig(out / "coverage_heatmap.png", dpi=160); plt.close(fig)


def save_random_comparison(planner, best, random_scores, output_dir="outputs"):
    out = Path(output_dir); out.mkdir(parents=True, exist_ok=True)
    fig, ax = plt.subplots(figsize=(8, 5))
    ax.hist(random_scores, bins=30, alpha=0.8, edgecolor="black")
    ax.axvline(best.fitness, linestyle="--", linewidth=2, label=f"GA best = {best.fitness:.3f}")
    ax.set(title="Genetic Algorithm vs Random Search", xlabel="Fitness", ylabel="Number of random candidates")
    ax.legend(); ax.grid(axis="y", alpha=0.2); fig.tight_layout()
    fig.savefig(out / "random_search_comparison.png", dpi=160); plt.close(fig)
