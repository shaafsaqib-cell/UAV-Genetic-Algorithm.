"""Genetic Algorithm for multi-drone disaster-grid mission planning."""
from dataclasses import dataclass
import math
import random
from typing import List, Tuple
import numpy as np

Point = Tuple[int, int]

@dataclass
class DronePlan:
    start: Point
    waypoints: List[Point]
    speeds: List[int]
    sensors: List[int]

@dataclass
class Chromosome:
    plans: List[DronePlan]
    fitness: float = float("-inf")
    metrics: dict = None

class DisasterGrid:
    """Synthetic grid: 0=safe, 1=blocked, risk in [0,1], priority in [0,1]."""
    def __init__(self, size=50, seed=42):
        self.size = size
        rng = np.random.default_rng(seed)
        self.blocked = np.zeros((size, size), dtype=bool)
        self.risk = rng.uniform(0.0, 0.15, (size, size))
        self.priority = np.zeros((size, size), dtype=float)

        # Rectangular no-fly zones, with small gaps so routes remain feasible.
        for x0, y0, x1, y1 in [(10, 8, 15, 23), (26, 3, 31, 17),
                               (34, 28, 42, 34), (7, 34, 19, 39)]:
            self.blocked[y0:y1, x0:x1] = True
        # High-risk pockets.
        for cx, cy, radius, level in [(22, 27, 7, 0.9), (39, 12, 5, 0.75),
                                      (14, 44, 4, 0.65)]:
            yy, xx = np.mgrid[0:size, 0:size]
            mask = (xx-cx)**2 + (yy-cy)**2 <= radius**2
            self.risk[mask] = np.maximum(self.risk[mask], level)
        # Priority targets / disaster hotspots.
        for cx, cy, radius, level in [(8, 7, 5, 1.0), (37, 22, 6, 0.9),
                                      (24, 43, 5, 0.85), (44, 44, 4, 0.8)]:
            yy, xx = np.mgrid[0:size, 0:size]
            mask = (xx-cx)**2 + (yy-cy)**2 <= radius**2
            self.priority[mask] = np.maximum(self.priority[mask], level)
        self.priority[self.blocked] = 0.0
        self.risk[self.blocked] = 1.0

    def valid(self, p):
        x, y = p
        return 0 <= x < self.size and 0 <= y < self.size and not self.blocked[y, x]

    def repair_point(self, p):
        """Clamp coordinates and move blocked points to the nearest safe cell."""
        x = int(np.clip(round(p[0]), 0, self.size-1))
        y = int(np.clip(round(p[1]), 0, self.size-1))
        if self.valid((x, y)):
            return (x, y)
        for radius in range(1, self.size):
            candidates = []
            for yy in range(max(0, y-radius), min(self.size, y+radius+1)):
                for xx in range(max(0, x-radius), min(self.size, x+radius+1)):
                    if max(abs(xx-x), abs(yy-y)) == radius and self.valid((xx, yy)):
                        candidates.append((xx, yy))
            if candidates:
                return min(candidates, key=lambda q: (q[0]-x)**2+(q[1]-y)**2)
        return (0, 0)

class GeneticPlanner:
    def __init__(self, grid, num_drones=3, waypoints=8, population_size=70,
                 generations=100, mutation_rate=0.12, tournament_size=4,
                 elitism=2, seed=42):
        self.grid = grid
        self.num_drones = num_drones
        self.waypoints = waypoints
        self.population_size = population_size
        self.generations = generations
        self.mutation_rate = mutation_rate
        self.tournament_size = tournament_size
        self.elitism = elitism
        self.rng = random.Random(seed)
        self.starts = [(2, 2), (2, grid.size-3), (grid.size-3, 2)]
        self.history_best = []
        self.history_avg = []
        self.best = None

    def random_point(self):
        for _ in range(100):
            p = (self.rng.randrange(self.grid.size), self.rng.randrange(self.grid.size))
            if self.grid.valid(p):
                return p
        return (1, 1)

    def random_chromosome(self):
        plans = []
        for i in range(self.num_drones):
            start = self.grid.repair_point(self.starts[i % len(self.starts)])
            pts = [self.random_point() for _ in range(self.waypoints)]
            speeds = [self.rng.randint(1, 3) for _ in range(self.waypoints)]
            sensors = [self.rng.randint(0, 2) for _ in range(self.waypoints)]
            plans.append(DronePlan(start, pts, speeds, sensors))
        c = Chromosome(plans)
        self.evaluate(c)
        return c

    def path_points(self, plan):
        return [plan.start] + plan.waypoints

    def evaluate(self, chromosome):
        covered = np.zeros((self.grid.size, self.grid.size), dtype=bool)
        total_energy = total_time = total_risk = total_distance = 0.0
        violations = 0
        detected_priority = 0.0
        total_priority = float(self.grid.priority.sum()) + 1e-9
        for plan in chromosome.plans:
            points = self.path_points(plan)
            drone_distance = 0.0
            for idx, p in enumerate(points):
                p = self.grid.repair_point(p)
                if not self.grid.valid(p):
                    violations += 1
                x, y = p
                sensor = plan.sensors[min(idx, len(plan.sensors)-1)] if plan.sensors else 0
                speed = plan.speeds[min(idx, len(plan.speeds)-1)] if plan.speeds else 1
                radius = 1.0 + sensor * 1.5
                x0, x1 = max(0, int(x-radius)), min(self.grid.size, int(x+radius+1))
                y0, y1 = max(0, int(y-radius)), min(self.grid.size, int(y+radius+1))
                yy, xx = np.mgrid[y0:y1, x0:x1]
                mask = (xx-x)**2 + (yy-y)**2 <= radius**2
                local_priority = self.grid.priority[y0:y1, x0:x1]
                local_blocked = self.grid.blocked[y0:y1, x0:x1]
                valid_mask = mask & (~local_blocked)
                covered[y0:y1, x0:x1] |= valid_mask
                detected_priority += float((local_priority * valid_mask).sum()) / max(1, self.num_drones)
                total_energy += 0.8 + 0.55*sensor + 0.22*speed**2
                total_risk += float(self.grid.risk[y, x]) * (1.0 + 0.25*sensor)
                if idx > 0:
                    prev = points[idx-1]
                    d = math.dist(prev, p)
                    drone_distance += d
                    total_distance += d
                    total_time += d / (0.8 + 0.45*speed)
            if drone_distance > 180:
                violations += 1
                total_energy += 30.0 * (drone_distance - 180) / 180
        coverage = float(covered.sum()) / float((~self.grid.blocked).sum())
        detection = min(1.0, detected_priority / total_priority)
        # Soft penalty for segment jumps through blocked cells, sampled along each segment.
        for plan in chromosome.plans:
            pts = self.path_points(plan)
            for a, b in zip(pts, pts[1:]):
                n = max(2, int(math.dist(a, b) * 1.5))
                for t in np.linspace(0, 1, n):
                    q = (round(a[0] + t*(b[0]-a[0])), round(a[1] + t*(b[1]-a[1])))
                    if not self.grid.valid(q):
                        violations += 1
                        break
        risk_cost = total_risk / max(1, sum(len(self.path_points(p)) for p in chromosome.plans))
        penalty = violations * 2.0
        fitness = (8.0*coverage + 4.0*detection
                   - 0.035*total_energy - 0.025*total_time
                   - 0.12*risk_cost - penalty)
        chromosome.fitness = fitness
        chromosome.metrics = {
            "coverage": coverage, "detection": detection, "energy": total_energy,
            "time": total_time, "risk": risk_cost, "violations": violations,
            "distance": total_distance
        }
        return fitness

    def select(self, population):
        contestants = self.rng.sample(population, min(self.tournament_size, len(population)))
        return max(contestants, key=lambda c: c.fitness)

    def crossover(self, parent_a, parent_b):
        """Drone/waypoint segment crossover; each child segment comes from one parent."""
        child_plans = []
        for pa, pb in zip(parent_a.plans, parent_b.plans):
            cut = self.rng.randrange(1, self.waypoints) if self.waypoints > 1 else 0
            pts = pa.waypoints[:cut] + pb.waypoints[cut:]
            speeds = pa.speeds[:cut] + pb.speeds[cut:]
            sensors = pa.sensors[:cut] + pb.sensors[cut:]
            # Occasionally swap the entire route segment from the other parent.
            if self.rng.random() < 0.25:
                pts, speeds, sensors = pb.waypoints[:], pb.speeds[:], pb.sensors[:]
            repaired = [self.grid.repair_point(p) for p in pts]
            child_plans.append(DronePlan(pa.start, repaired, speeds, sensors))
        child = Chromosome(child_plans)
        self.evaluate(child)
        return child

    def mutate(self, chromosome):
        for plan in chromosome.plans:
            for i, p in enumerate(plan.waypoints):
                if self.rng.random() < self.mutation_rate:
                    # Local spatial mutation usually preserves route structure.
                    if self.rng.random() < 0.75:
                        dx, dy = self.rng.randint(-6, 6), self.rng.randint(-6, 6)
                        candidate = (p[0] + dx, p[1] + dy)
                    else:
                        candidate = self.random_point()
                    plan.waypoints[i] = self.grid.repair_point(candidate)
                if self.rng.random() < self.mutation_rate:
                    plan.speeds[i] = self.rng.randint(1, 3)
                if self.rng.random() < self.mutation_rate:
                    plan.sensors[i] = self.rng.randint(0, 2)
        self.evaluate(chromosome)
        return chromosome

    def run(self):
        population = [self.random_chromosome() for _ in range(self.population_size)]
        for generation in range(self.generations):
            population.sort(key=lambda c: c.fitness, reverse=True)
            self.history_best.append(population[0].fitness)
            self.history_avg.append(float(np.mean([c.fitness for c in population])))
            self.best = population[0]
            new_population = [self.clone(c) for c in population[:self.elitism]]
            while len(new_population) < self.population_size:
                p1, p2 = self.select(population), self.select(population)
                child = self.crossover(p1, p2)
                if self.rng.random() < self.mutation_rate:
                    child = self.mutate(child)
                new_population.append(child)
            population = new_population
        population.sort(key=lambda c: c.fitness, reverse=True)
        if self.best is None or population[0].fitness > self.best.fitness:
            self.best = population[0]
        return self.best

    def clone(self, c):
        plans = [DronePlan(p.start, p.waypoints[:], p.speeds[:], p.sensors[:]) for p in c.plans]
        return Chromosome(plans, c.fitness, dict(c.metrics or {}))

def random_search(grid, planner, samples=1000, seed=123):
    """Baseline: evaluate independent random missions with the same fitness function."""
    rng_state = planner.rng.getstate()
    planner.rng.seed(seed)
    best = None
    scores = []
    for _ in range(samples):
        candidate = planner.random_chromosome()
        scores.append(candidate.fitness)
        if best is None or candidate.fitness > best.fitness:
            best = candidate
    planner.rng.setstate(rng_state)
    return best, scores
